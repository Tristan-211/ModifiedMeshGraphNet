#!/bin/bash

srun python plot_deform.py
